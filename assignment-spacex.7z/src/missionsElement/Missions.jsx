import React, { useState, useEffect } from 'react'
import MissionCard from './MissionCard'
import './Missions.css'
import { formattedSpacexData } from '../services/FetchData'
function Missions() {
    const [finalData, setFinalData] = useState('')
    useEffect(() => {
        const fetchData = async () => {
            let temp = await formattedSpacexData();
            setFinalData(temp);
        }
        fetchData();
    }, []);
    // console.log('inside missions data', finalData)
    return (
        <div className='cards'>
            {
                finalData && finalData.map((element, index) => {
                    return <MissionCard key={index} mission_name={element.mission_name} flight_number={element.flight_number} mission_id={element.mission_id} launch_year={element.launch_year} launch_success={element.launch_success} mission_patch={element.mission_patch} land_success={element.land_success} />
                })
            }
        </div >
    )
}

export default Missions
// 
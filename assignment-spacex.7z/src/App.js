import './App.css';
import Filters from './filterElement/Filters';
import Missions from './missionsElement/Missions';

function App() {
  return (
    <div className='mainContainer'>
      <div className='filters'><Filters /></div>
      <div className='missions'><Missions /></div>
    </div>
  );
}

export default App;
